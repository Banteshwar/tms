<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrderLocation extends Model
{
    //

    protected $guarded = ['_token'];
    
}
