<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrderBasic extends Model
{
    //
    protected $guarded =  ["_token"];
}
