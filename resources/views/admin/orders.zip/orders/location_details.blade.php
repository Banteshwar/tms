  @php
// echo "<pre>";
//   print_r($basicLocation->sch_at);
  @endphp

  <table class = "table">
    <tbody>
      <thead>
        <tr>
          <td>Task</td>
          <td>Name</td>
          <td>Address</td>
          <td>Appointment</td>
        </tr>
      </thead>
      <tr>
        <td> Sch. at </td>
        <td> {{ $basicLocation->sch_at ?? '' }} </td>
        <td> {{ $basicLocation->sch_at ?? '' }} </td>
        <td> {{ $basicLocation->appointment_date ?? '' }} </td>
      </tr>

        @forelse($addedLocation as $location)
            <tr>  
              <td>{{ $location->doing_in_location }}</td>
              <td>{{ $location->location }}</td>
              <td>{{ $location->address }}</td>
              <td>{{ $location->appointment_date }}</td>
              
            </tr>
        @empty
          
        @endforelse

      <tr>
        <td> Terminated at </td>
        <td> {{ $basicLocation->terminated_at ?? '' }} </td>
      </tr>

    </tbody>
  </table>