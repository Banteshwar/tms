@extends('layouts.backend')
	@section('content')
	@include('admin.orders.top_menu')
	<div class="m-content">
		<div class="row">
			<div class="col-md-6">
				<!--begin::Portlet-->
				<div class="m-portlet m-portlet--tab">
					<div class="m-portlet__head">
						<div class="m-portlet__head-caption">
							<div class="m-portlet__head-title">
								<span class="m-portlet__head-icon m--hide">
									<i class="la la-gear"></i>
								</span>
								<h3 class="m-portlet__head-text">
											Add Trips 
								</h3>
							</div>
						</div>
					</div>
					<!--begin::Form-->
					{{ Form::open(['route' => 'driver.uploaddocuments', 'class' => 'm-form m-form--fit m-form--label-align-right -group-seperator-dashed','files'=>true]) }}
					
						<div class="m-portlet__body">
							<div class="form-group m-form__group row">								
								<div class="col-1">
									<label class="col-form-label">
										Driver
									</label>									
								</div>
								<div class="col-4">
									{{ Form::select('driver', ['CA' => 'CA',
														   'USA' => 'USA'],
														    null, 
															['class' => 'form-control m-input m-input--square'])   
									}}								
								</div>
								<div class="col-1">
									<label class="col-form-label">
										Trucks
									</label>									
								</div>
								<div class="col-3">
									{{ Form::select('truks', ['CA' => 'CA',
														   'USA' => 'USA'],
														    null, 
															['class' => 'form-control m-input m-input--square'])   
									}}									
								</div>
								<div class="col-3">
									{{ Form::select('terminal', ['CA' => 'CA',
													   'USA' => 'USA'],
													    null, 
														['class' => 'form-control m-input m-input--square'])   
									}}							
								</div>
							</div>
							<hr/>
							<div class="form-group m-form__group row">
								<div class="col-1 ">
									<label class="col-form-label">Trip Stops</label>
								</div>
								<div class="col-11">

									<table class="table">
									    <thead>
									      <tr>
									        <th ><input type="checkbox" ></th>
									        <th>Truck</th>
									        <th></th>
									        <th></th>
									      </tr>
									    </thead>
									    <tbody>
									      <tr>
									        <td ><input type="checkbox" ></td>
									        <td >3607</td>
									        <td style="width: 70%;">
											<select tabindex="-98" style="width: 40%;" >
												<optgroup label="-------" data-max-options="2" >
													<option value="Pickup - loaded" >Pickup - loaded </option>
													<option value="Deliver" >Deliver </option>
													<option value="Return - empty" >Return - empty </option>
													<option value="Bring to Yard- Loaded" >Bring to Yard- Loaded </option>
													<option value="Pickup from Yard- Loaded" >Pickup from Yard- Loaded </option>
													<option value="Bring to Yard - Empty" >Bring to Yard - Empty </option>
													<option value="Pickup from Yard - Empty" >Pickup from Yard - Empty </option>
												</optgroup>
												<optgroup label="-------" data-max-options="2">
													<option value = "Bobtail From" >  Bobtail From </option>
													<option value = "Bobtail To" >  Bobtail To </option>
												</optgroup>
												<optgroup label="-------" data-max-options="2">
													<option value = "Bring Chassis to Yard" >  Bring Chassis to Yard </option>
													<option value = "Pickup Chassis from Yard" >  Pickup Chassis from Yard </option>
													<option value = "Pickup Chassis" >  Pickup Chassis </option>
													<option value = "Return Chassis" >  Return Chassis </option>
												</optgroup>
												<optgroup label="-------" data-max-options="2">
													<option value = "Pickup Third-Party Container" >  Pickup Third-Party Container </option>
													<option value = "Bring Third-Party Container to Yard" >  Bring Third-Party Container to Yard </option>
													<option value = "Pickup Third-Party Container from Yard" >  Pickup Third-Party Container from Yard </option>
													<option value = "Return Third-Party Container" >  Return Third-Party Container </option>
												</optgroup>
												<optgroup label="-------" data-max-options="2">
													<option value = "Street Turn" >  Street Turn </option>
													<option value = "Close Move" >  Close Move </option>
												</optgroup>
												
											</select>

											at

											{{ Form::select('sch_at', 
												[
													   '1' => 'BNSF-BNSF- Oakland International Gateway,Oakland, CA',
													   '2' => 'OICT-Oakland International Container Terminal , Oakland, CA',
														'3' => 'PAO-Ports America Oakland, Oakland,CA',
														'4' => 'TRAPAC-TraPac, Oakland, CA',
														'5' => 'UPFS-UP- Ferro Street, Oakland, CA',
														'6' => 'UPMH-UP - Middle Harbor, Oakland, CA'
												],
											    null, 
												['style' => 'width: 40%'])   
											}}							
											</td>
											<td>+ - </td>
									      </tr>
									     
									     
									    </tbody>
									  </table>
								</div>
							</div>
							<hr/>

							<div class="form-group m-form__group row">
								<div class="col-3">
									<label class="col-form-label"> Start Date </label>
								</div>
								<div class="col-lg-4 ">
									<div class="input-group date" id="m_datepicker_3" data-date-format="yyyy-mm-dd" >                              

	                                {!! Form::text('trip_start_date', null, ['class' => 'form-control m-input','id'=>'trip_start_date', 'required' => 'required','placeholder'=>'Sch. Date']) !!}

	                                    <span class="input-group-addon">
	                                        <i class="la la-calendar"></i>
	                                    </span>
	                                </div>
                                </div>

								<div class="col-1 ">
									<label class="col-form-label"> Time </label>
								</div>

								<div class="col-lg-4 ">
									<div class="input-group timepicker">
										
										{!! Form::text('trip_start_time', null, ['class' => 'form-control','id'=>'m_timepicker_1', 'required' => 'required', 'readonly' =>'', 'placeholder'=>'Select time']) !!}

										<span class="input-group-addon">
											<i class="la la-clock-o"></i>
										</span>
									</div>
								</div>

							</div>

							<div class="form-group m-form__group row">
								<div class="col-3">
									<label class="col-form-label"> Completed Date </label>
								</div>
								<div class="col-lg-4 ">
									<div class="input-group date" id="m_datepicker_3" data-date-format="yyyy-mm-dd" >                              

	                                {!! Form::text('trip_completed_date', null, ['class' => 'form-control m-input','id'=>'trip_completed_date', 'required' => 'required','placeholder'=>'Completed Date']) !!}

	                                    <span class="input-group-addon">
	                                        <i class="la la-calendar"></i>
	                                    </span>
	                                </div>
                                </div>

								<div class="col-1 ">
									<label class="col-form-label"> Time </label>
								</div>

								<div class="col-lg-4 ">
									<div class="input-group timepicker">
										
										{!! Form::text('trip_completed_time', null, ['class' => 'form-control','id'=>'m_timepicker_1', 'required' => 'required', 'readonly' =>'', 'placeholder'=>'Select time']) !!}

										<span class="input-group-addon">
											<i class="la la-clock-o"></i>
										</span>
									</div>
								</div>
							</div>

							<div class="form-group m-form__group row">
								<div class="col-lg-3">
								
									<label class="col-form-label">
										Comments:
									</label>
								</div>

								<div class="col-lg-9" >
								{!! Form::textarea('comments', null, ['class' => 'form-control m-input m-input','id'=>'comments', 'required' => 'required','size' => '50x3','placeholder'=>'Comments']) !!}
								</div>
							</div>

							<hr/>
						
							<div class="form-group m-form__group row">
								
								<div class="col-12">
									<label class="col-form-label">
										Add Payments Details Here:
									</label>
									<table class="table">
									    <thead>
									      <tr>
									        <th>Pay Type</th>
									        <th>Units</th>
									        <th>Rates</th>
									        <th>Amounts</th>
									        <th></th>
									      </tr>
									    </thead>
									    <tbody>
									      <tr>
									        <td style = "width: 30%">
									        	{{ Form::select('pay_type', 
												[
												   'Additional Dray'  =>  'Additional Dray' ,
													'Attempted Pickup'  =>  'Attempted Pickup' ,
													'Bobtail'  =>  'Bobtail' ,
													'Chassis Reposition'  =>  'Chassis Reposition' ,
													'Chassis Split'  =>  'Chassis Split' ,
													'Detention'  => 'Detention' ,
													'Dry Run'  =>  'Dry Run' ,
													'Fuel Surcharge'  =>  'Fuel Surcharge' ,
													'Hauling Refrigerated Cargo'  =>  'Hauling Refrigerated Cargo' ,
													'Hazardous Materials'  =>  'Hazardous Materials' ,
													'Hazardous Materials'  =>  'Hazardous Materials' ,
													'Heavy'  =>  'Heavy' ,
													'Local Move'  =>  'Local Move' ,
													'Miscellaneous'  =>  'Miscellaneous' ,
													'Other'  => 'Other' ,
													'Scale'  =>  'Scale' ,
													'Stop Off'  => 'Stop Off' ,
													'Toll'  => 'Toll' ,
													'Triaxle'  =>  'Triaxle' ,
													'Trip Pay'  =>  'Trip Pay' ,
												],
											    null, 
												['class' => 'pay_type','style' => 'width: 100%'])   
											}}		
 											</td>
									        <td>
									        	{!! Form::text('units', null, ['class' => 'form-control','id'=>'units', 'placeholder'=>'Units']) !!}
									        </td>
									        <td>
									        	{!! Form::text('rates', null, ['class' => 'form-control','id'=>'rates', 'placeholder'=>'Rates']) !!}
									        </td>

									        <td>
									        	{!! Form::text('amount', null, ['class' => 'form-control','id'=>'amount', 'placeholder'=>'Amounts']) !!}
									        </td>


											<td>Add More</td>
									      </tr>
									     
									     
									    </tbody>
									  </table>
								</div>
							</div>
							<hr/>
						</div>
						<div class="m-portlet__foot m-portlet__foot--fit">
							<div class="m-form__actions">
								<div class="row">
									<div class="col-2"></div>
									<div class="col-10">
										<button type="submit" class="btn btn-success">
											Submit
										</button>
										<button type="reset" class="btn btn-secondary">
											Cancel
										</button>
									</div>
								</div>
							</div>
						</div>
					{{ Form::close() }}
					
					
					<!--end::Form-->
				</div>
				<!--end::Portlet-->
			</div>
			<div class="col-md-6">				
				<div class="m-portlet m-portlet--tab">
					<div class="m-portlet__head">
						<div class="m-portlet__head-caption">
							<div class="m-portlet__head-title">
								<span class="m-portlet__head-icon m--hide">
									<i class="la la-gear"></i>
								</span>
								<h3 class="m-portlet__head-text">
									Trips - Click on the truck to Select
								</h3>
							</div>
						</div>
					</div>

					
					<div class="m-portlet__body">

						<div class="form-group m-form__group row">
								
								<div class="col-12">
									
									<table class="table">
									    <thead>
									      <tr>
									        <th></th>
									        <th>No</th>
									        <th>Truck</th>
									        <th>Start</th>
									        <th>Trip Pay</th>
									        <th>Status</th>
									        <th>Delete</th>
									      </tr>
									    </thead>
									    <tbody>
									      <tr>
									        <td>
									        	
 											</td>
									        <td>
									        	
									        </td>
									        <td>
									        	
									        </td>

									        <td>
									        	
									        </td>

											<td>
									        	
									        </td> 

									        <td>
									        	
									        </td>
											<td>D</td>
									      </tr>
									     
									      <tr>
									        <td colspan="7" align="Center">
									        	Total : 
 											</td>
									        
									      </tr>
									    </tbody>
									  </table>
								</div>
							</div>
							<hr/>
					</div>

				</div>


				<div class="m-portlet m-portlet--tab">
					<div class="m-portlet__head">
						<div class="m-portlet__head-caption">
							<div class="m-portlet__head-title">
								<span class="m-portlet__head-icon m--hide">
									<i class="la la-gear"></i>
								</span>
								<h3 class="m-portlet__head-text">
									Trips Details
								</h3>
							</div>
						</div>
					</div>

					
					<div class="m-portlet__body">

						<div class="form-group m-form__group row">
								
								<div class="col-12">
									
									<table class="table">
									    <thead>
									      <tr>
									        <th>Trucks</th>
									        <th>Events/Location</th>
									        <th>Completed Date Time</th>
									        <th>With L/E</th>
									       {{--  <th>Recorded By</th>
									        <th>Recorded Time</th> --}}
									        
									      </tr>
									    </thead>
									    <tbody>
									      <tr>
									        <td>
									        	
 											</td>
									        <td>
									        	
									        </td>
									        <td>
									        	
									        </td>

									        <td>
									        	
									        </td>

											{{-- <td>
									        	
									        </td> 

									        <td>
									        	
									        </td> --}}
											
									      </tr>
									     
									      
									    </tbody>
									  </table>
								</div>
							</div>
							<hr/>
					</div>

				</div>
			</div>						
		</div>
	</div>

@endsection	